let handler = async m => m.reply(`𝚂𝚄𝙿𝙿𝙾®𝚃 𝙶𝚁𝙾𝚄𝙿 𝙻𝙸𝙽𝙺
 ★☆⚡𝑷-𝑴𝑫⚡☆★

*${mssg.link}*: https://chat.whatsapp.com/Jo5bmHMAlZpEIp75mKbwxP

*${mssg.link}*: https://whatsapp.com/channel/0029VaKNbWkKbYMLb61S1v11

*OWNER*
${developer}
`.trim())
handler.help = ['support']
handler.tags = ['main']
handler.command = ['support', 'sup'] 

export default handler
